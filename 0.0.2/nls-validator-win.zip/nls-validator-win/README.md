📘 Nielsen SDK Validator - User Guide
====================================

This package is designed to validate the integration of the Nielsen SDK
in iOS and Android apps by capturing logs and showing validation results
in your web browser.

---

🖥️ What Happens After You Install
----------------------------------
✅ You’ll unzip the package and get:
  - `validator-binary` (the executable tool)
  - `nls-validator.command` (double-click launcher)
  - On first run, Control-click nls-validator.command → Open → then click Open again in the warning dialog.
  - If macOS still blocks it, go to System Settings → Privacy & Security, scroll to Security, click “Allow Anyway / Open   Anyway” for nls-validator.command and then try again.
✅ The tool launches automatically in your browser
✅ You can double-click the `.command` file again to relaunch anytime

---

▶️ How to Use the Validator
---------------------------
1. Connect your device or boot simulator/emulator:
   - iOS device must be unlocked and "trusted"
   - Android phone must have USB debugging enabled
   - iOS simulator or Android emulator must be booted via Xcode or Android Studio

2. Double-click the `nls-validator.command` file
   - A browser window will open automatically
   - You’ll see live logs and a validation checklist

3. If no logs appear, check the "Troubleshooting" section below

---

🧰 One-Time Requirements (per platform)
--------------------------------------

🔹 For iOS device logs:
   - Run in Terminal:
     `brew install libimobiledevice`
   - Approve "Trust This Computer" on your iPhone when prompted

🔹 For Android device logs:
   - Ensure `adb` is installed and available in PATH:
     - Easiest: `brew install android-platform-tools`
     - Or use Android Studio’s `platform-tools` directory
   - On your phone:
     - Enable Developer Options
     - Enable "USB debugging"
     - Connect via USB and accept debugging prompt
   - Run this to test:
     `adb devices` → should show your phone's serial number

🔹 For iOS Simulator:
   - Open Xcode > `Window > Devices and Simulators`
   - Boot a simulator (e.g., iPhone 14)

🔹 For Android Emulator:
   - Open Android Studio or run:
     `emulator -avd <your_avd_name>` from terminal

---

❗ Troubleshooting
------------------

🔸 Seeing: “No log capture method found”?
   - iOS device: check `idevice_id -l` shows a device
   - iOS simulator: ensure it's booted in Xcode
   - Android device: check `adb devices` shows a device
   - Android emulator: ensure it’s running and visible to `adb`

🔸 Seeing: “Permission denied” when double-clicking?
   - Right-click > Get Info > Make sure it's executable
   - Or run: `chmod +x ~/Desktop/nls-validator.command`

---


